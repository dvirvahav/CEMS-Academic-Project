package controller;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableView;

public class ExamsToApproveTeacherController {

    @FXML
    private TableView<?> contentTableView;

    @FXML
    private Button backButton;

}
